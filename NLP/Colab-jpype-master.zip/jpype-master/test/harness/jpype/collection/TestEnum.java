package jpype.collection;

enum TestEnum {
A,B
}