JPype
=====

.. image:: https://travis-ci.org/originell/jpype.png?branch=master
   :target: https://travis-ci.org/originell/jpype

.. image:: https://img.shields.io/appveyor/ci/originell/jpype.svg
   :target: https://ci.appveyor.com/project/originell/jpype


JPype is an effort to allow python programs full access to java class
libraries. 

Find the `documentation at Read the Docs
<http://jpype.readthedocs.org>`__.  Current development is done in
`the github project <https://github.com/originell/jpype>`__. The work
on this project began on `Sourceforge
<http://sourceforge.net/projects/jpype/>`__.
