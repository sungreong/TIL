
void JPRunConsoleEventLoop();
